﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SoftUni.Data;
using SoftUni.Data.Models;
using Microsoft.EntityFrameworkCore;
using System.Globalization;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var db = new SoftUniContext();
            Console.WriteLine(GetEmployeesInPeriod(db));
        }
        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            var employees = context.Employees.OrderBy(x => x.EmployeeId)

                .Select(y => new
                {
                    y.FirstName,
                    y.LastName,
                    y.MiddleName,
                    JobTitle = y.JobTitle,
                    Salary = $"{y.Salary:f2}"
                })
                .ToList();
            //.Take(10);

            var sb = new StringBuilder();

            foreach (var employee in employees)
            {
                List<string> valuesEmployee = new List<string>();
                foreach (var prop in employee.GetType().GetProperties())
                {
                    var type = prop.PropertyType.Name;
                    var value = prop.GetValue(employee);
                    if (value == null)
                    {
                        continue;
                    }
                    valuesEmployee.Add(value.ToString());
                }
                sb.AppendLine(string.Join(" ", valuesEmployee));
            }
            return sb.ToString().TrimEnd();

        }

        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            var employees = context.Employees.Where(s => s.Salary > 50000)
                .OrderBy(x => x.FirstName)
                                .Select(y => new
                                {
                                    y.FirstName,
                                    Salary = $"{y.Salary:f2}"
                                })
                .ToList();
            //.Take(10);

            var sb = new StringBuilder();

            foreach (var employee in employees)
            {
                List<string> valuesEmployee = new List<string>();
                foreach (var prop in employee.GetType().GetProperties())
                {
                    var type = prop.PropertyType.Name;
                    var value = prop.GetValue(employee);
                    if (value == null)
                    {
                        continue;
                    }
                    valuesEmployee.Add(value.ToString());
                }
                sb.AppendLine(string.Join(" - ", valuesEmployee));
            }
            return sb.ToString().TrimEnd();
        }

        public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
        {
            var employees = context.Employees
                .Where(d => d.Department.Name == "Research and Development")
                .OrderBy(s => s.Salary)
                .ThenByDescending(f => f.FirstName)
                                .Select(y => new
                                {
                                    y.FirstName,
                                    y.LastName,
                                    y.Department.Name,
                                    Salary = $"- ${y.Salary:f2}"
                                })
                .ToList();
            //.Take(10);

            var sb = new StringBuilder();

            foreach (var employee in employees)
            {
                List<string> valuesEmployee = new List<string>();
                foreach (var prop in employee.GetType().GetProperties())
                {
                    var type = prop.PropertyType.Name;
                    var value = prop.GetValue(employee);
                    if (value == null)
                    {
                        continue;
                    }
                    valuesEmployee.Add(value.ToString());
                }
                sb.AppendLine(string.Join(" ", valuesEmployee));
            }
            return sb.ToString().TrimEnd();
        }

        public static string AddNewAddressToEmployee(SoftUniContext context)
        {
            var newAddres = new Address();
            newAddres.AddressText = "Vitoshka 15";
            newAddres.TownId = 4;
            var employee = context.Employees.FirstOrDefault(l => l.LastName == "Nakov");
            employee.Address = newAddres;
            context.SaveChanges();
            var employeesAdrres = context.Employees
                .OrderByDescending(a => a.AddressId)
                .Select(t => t.Address.AddressText)
                /*
                .Select(t => new
                {
                    t.FirstName,
                    t.LastName,
                    t.Address.AddressText
                })
                */
                .ToList()
                .Take(10);

            return string.Join(Environment.NewLine, employeesAdrres);
        }


        public static string GetEmployeesInPeriod(SoftUniContext context)
        {
            var employees = context.Employees
                .Include(x=> x.EmployeesProjects)
                .ThenInclude(x=>x.Project)
                .Where(p => p.EmployeesProjects
                            .Any(d => d.Project.StartDate.Year >= 2001 && d.Project.StartDate.Year <= 2003))
                .Select( x=> new 
                {
                x.FirstName,
                x.LastName,
                ManagerFirstName=x.Manager.FirstName,
                MamagerLastName=x.Manager.LastName,
                Projects = x.EmployeesProjects.Select( p=> new
                {
                   ProjectName= p.Project.Name,
                    p.Project.StartDate,
                    p.Project.EndDate
                }

                    )
                })
                .ToList()
                .Take(10);
            foreach (var employee in employees)
            {
                var sb = new StringBuilder();
                sb.AppendLine($"{employee.FirstName} {employee.LastName} - Manager: {employee.ManagerFirstName} {employee.MamagerLastName}");
                foreach (var project in employee.Projects)
                {
                    var endDate = project.EndDate.HasValue ?
                        project.EndDate.Value.ToString("M/d/yyyy h:mm:ss tt",CultureInfo.InvariantCulture) :
                        "not finished";
                    sb.AppendLine($"--{project.ProjectName} - {project.StartDate.ToString("M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture)} - {endDate}");
                }
                Console.WriteLine(sb.ToString().TrimEnd());
            }
            /*
            Employees
                .Where(x => x.EmployeesProjects
                   .Any(s => s.Project.StartDate > startDate && s.Project.StartDate <= endDate))
                .Select(e => new
                {
                    e.FirstName,
                    e.LastName,
                    ManagerFirstName = e.Manager.FirstName,
                    ManagerLastName = e.Manager.LastName,
                })
                .ToList()
                .Take(10);


            */
            return null;
        }
    }
}
