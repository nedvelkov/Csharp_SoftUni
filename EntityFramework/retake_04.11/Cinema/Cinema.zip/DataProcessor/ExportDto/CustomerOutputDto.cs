﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cinema.DataProcessor.ExportDto
{
   public class CustomerOutputDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Balance { get; set; }
    }
}
