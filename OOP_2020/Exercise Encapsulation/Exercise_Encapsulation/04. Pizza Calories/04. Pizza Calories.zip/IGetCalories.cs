﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PizzaCalories
{
    interface IGetCalories
    {
        public double GetCalories();
        public double GetCaloriesPerGram();
    }
}
