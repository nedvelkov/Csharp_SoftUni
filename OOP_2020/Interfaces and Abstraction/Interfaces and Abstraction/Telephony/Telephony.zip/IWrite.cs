﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public interface IWrite
    {
        public void WriteLine(string text);
    }
}
