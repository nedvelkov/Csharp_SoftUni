﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl.Contracts
{
    public interface IPerson 
    {
        public string Name { get;  }
        public int Age { get;  }
    }
}
