﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl.Contracts
{
    public interface IPet:IBirthday
    {
        public string Name { get; }
    }
}
