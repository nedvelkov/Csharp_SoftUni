﻿
namespace BorderControl.Models
{
    using System;
    using BorderControl.Contracts;


    public class Person : Citizen, IPerson
    {
        private string name;
        private int age;
        private string id;

        public Person(string name, int age, string id) : base(id)
        {
            this.Name = name;
            this.Age = age;
        }

        public string Name
        {
            get => this.name;
            private set => this.name = value;
        }

        public int Age
        {
            get => this.age;
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Age must be possitive");
                }
                this.age = value;
            }

        }

        public string Id
        {
            get => this.id;
            private set => this.id = value;
        }
    }
}
