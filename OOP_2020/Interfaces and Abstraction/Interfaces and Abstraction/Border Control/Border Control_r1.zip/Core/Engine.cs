﻿

namespace BorderControl.Core

{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using BorderControl.Contracts;
    using BorderControl.Models;


    public class Engine
    {
        private IList<ICitizen> citizens;
        private IList<IBirthday> birthdays;
        public Engine()
        {
            this.citizens = new List<ICitizen>();
            this.birthdays = new List<IBirthday>();
        }

        public void Run()
        {
            while (true)
            {
                string input = Console.ReadLine();
                if (input.Equals("End")) break;
                var tokkens = input.Split();
                string name;
                string id;
                string model;
                int age;
                string birthday;
                try
                {
                    switch (tokkens[0])
                    {
                        case "Robot ":
                            model = tokkens[1];
                            id = tokkens[2];
                            Robot robot = new Robot(model, id);
                            this.citizens.Add(robot);
                            break;
                        case "Citizen":
                            name = tokkens[1];
                            age = int.Parse(tokkens[2]);
                            id = tokkens[3];
                            birthday = tokkens[4];
                            Citizen person = new Citizen(name, age, id,birthday);
                            this.citizens.Add(person);
                            this.birthdays.Add(person);
                            break;
                        case "Pet":
                            name = tokkens[1];
                            birthday = tokkens[2];
                            Pet pet = new Pet(name, birthday);
                            this.birthdays.Add(pet);

                            break;

                    }
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.Message);
                }
            }
        }

        public void Detain()
        {
            string lastDigitsID = Console.ReadLine();
            foreach (var current in this.citizens)
            {
                var currentID = current.GetIdNumber();
                if (currentID.EndsWith(lastDigitsID))
                {
                    Console.WriteLine(current.GetIdNumber());
                }
            }
        }
        public void SelebrateBirthday()
        {
            string year = Console.ReadLine();
            foreach (var birthdate in this.birthdays)
            {
                var currentYear = birthdate.Birthday;
                if (currentYear.EndsWith(year))
                {
                    Console.WriteLine(currentYear);
                }
            }
        }

    }
}
