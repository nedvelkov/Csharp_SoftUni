﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Core
{
    using Models;
    using Contracts;
    public class Engine
    {
        private IList<IVehicle> vehicles;

        public Engine()
        {
            this.vehicles = new List<IVehicle>();
        }

        public void AddVehicle()
        {
            var carInput = Console.ReadLine().Split();
            var truckInput = Console.ReadLine().Split();

            var carFuel = double.Parse(carInput[1]);
            var carConsumption = double.Parse(carInput[2]);
            var truckFuel = double.Parse(truckInput[1]);
            var truckConsumption = double.Parse(truckInput[2]);

            Car car = new Car(carFuel, carConsumption);
            Truck truck = new Truck(truckFuel, truckConsumption);

            this.vehicles.Add(car);
            this.vehicles.Add(truck);
        }
        public void MoveVehicle()
        {
            int commands = int.Parse(Console.ReadLine());
            for (int i = 0; i < commands; i++)
            {
                var tokkens = Console.ReadLine().Split();
                var command = tokkens[0];
                string type;
                double distance;
                double fuel;
                switch (command)
                {
                    case "Drive":
                        type = tokkens[1];
                        distance = double.Parse(tokkens[2]);
                        foreach (var vehicle in this.vehicles)
                        {
                            if (vehicle.GetType().Name.Equals(type))
                            {
                                vehicle.Drive(distance);
                            }
                        }
                        break;
                    case "Refuel":
                        type = tokkens[1];
                        fuel = double.Parse(tokkens[2]);
                        foreach (var vehicle in this.vehicles)
                        {
                            if (vehicle.GetType().Name.Equals(type))
                            {
                                vehicle.Refuel(fuel);
                            }
                        }
                        break;
                }

            }

            foreach (var vehicle in this.vehicles)
            {
                var name = vehicle.GetType().Name;
                Console.WriteLine($"{name}: {vehicle.FuelQuantity:f2}");
            }
        }
    }
}
