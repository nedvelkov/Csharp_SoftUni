﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Models
{
    using Contracts;
    public class Car : IVehicle
    {
        private double fuelQuantity;
        private double fuelConsumption;
        private const double extraConsumption = 0.9;
        public Car(double fuel,double consumpion)
        {
            this.FuelQuantity = fuel;
            this.FuelConsumption = consumpion;
        }

        public double FuelQuantity {
            get => this.fuelQuantity;
            private set
            {
                if (value < 0)
                {
                    throw new AggregateException("Fuel can't be negative");
                }
                this.fuelQuantity = value;
            }
        }

        public double FuelConsumption {
            get => this.fuelConsumption;
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Consumption can't be negative");
                }
                this.fuelConsumption = value+ extraConsumption;
            }
        }

        public void Drive(double distance)
        {
            double needFuel = distance * this.fuelConsumption;
            if (needFuel > this.fuelQuantity)
            {
                Console.WriteLine("Car needs refueling");
                return;
            }
            this.fuelQuantity -= needFuel;
            Console.WriteLine($"Car travelled {distance} km");
        }

        public void Refuel(double fuel)
        {
            if (fuel > 0)
            {
                this.fuelQuantity += fuel;
            }
        }
    }
}
