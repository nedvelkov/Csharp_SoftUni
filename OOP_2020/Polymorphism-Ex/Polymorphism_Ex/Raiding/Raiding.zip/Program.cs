﻿using System;
using System.Collections.Generic;

namespace Raiding
{
    using Core;
    class Program
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.AddToRaidGroup();
            engine.RaidBoss();
        } 
    }
}
