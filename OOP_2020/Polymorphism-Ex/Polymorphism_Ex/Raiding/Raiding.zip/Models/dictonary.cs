﻿namespace Raiding.Models
{
    internal class dictonary<T>
    {
    }
}