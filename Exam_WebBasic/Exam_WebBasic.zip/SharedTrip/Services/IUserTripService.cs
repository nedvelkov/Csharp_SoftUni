﻿namespace SharedTrip.Services
{
   public interface IUserTripService
    {
        public int FreeSeatTrip(string userId, string tripId);
    }
}
