﻿namespace SharedTrip.Services
{
   public interface ITripService
    {
        public bool ValidTrip(string id);
    }
}
